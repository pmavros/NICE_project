require("jest-canvas-mock");
