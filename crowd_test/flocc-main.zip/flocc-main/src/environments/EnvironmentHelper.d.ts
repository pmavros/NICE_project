interface EnvironmentHelper {}
