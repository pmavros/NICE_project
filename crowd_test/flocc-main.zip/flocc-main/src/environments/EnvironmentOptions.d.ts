declare interface EnvironmentOptions {
  torus?: boolean;
  width?: number;
  height?: number;
}
