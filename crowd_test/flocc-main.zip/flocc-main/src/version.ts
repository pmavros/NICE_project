/**
 * The current version of the Flocc library.
 */
const version: string = "0.5.20";
export default version;
