declare interface Data {
  [key: string]: any;
}
