/**
 * This is the doc comment for file1.ts
 *
 * Specify this is a module comment without renaming it:
 * @module
 */
export default interface HeatmapAxis extends NRange {
  buckets: number;
  key: string;
}
