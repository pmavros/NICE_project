declare interface NRange {
  min: number;
  max: number;
}
