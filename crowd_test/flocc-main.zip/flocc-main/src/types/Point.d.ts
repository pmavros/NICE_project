declare interface Point {
  x: number;
  y: number;
  z?: number;
}
